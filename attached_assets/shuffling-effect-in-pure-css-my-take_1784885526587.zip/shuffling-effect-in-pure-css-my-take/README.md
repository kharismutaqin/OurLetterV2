# Shuffling Effect in Pure CSS (my take)

A Pen created on CodePen.

Original URL: [https://codepen.io/cbolson/pen/MYgrjrm](https://codepen.io/cbolson/pen/MYgrjrm).

My take on the Cool Shuffling Effect in Pure CSS as created by Toni Lijic @tonilijic
https://www.toni.li/about

Chris Coyer and Jason Lengstorf demonstrated how they would approach this on a live stream (which I missed). Before watching their stream or looking at any source code I wanted to have a go myself.

This is a pure CSS version. Not overly practical but still fun to do.
Still a but buggy regarding the ordering when going backwards
